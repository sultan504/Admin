-- ==================================================================
-- eFootball Championship — full database setup
-- ==================================================================
-- Run this whole file once in Supabase → SQL Editor → New query → Run.
--
-- It is SAFE to run on your existing project: every statement uses
-- IF NOT EXISTS / OR REPLACE / DROP-then-CREATE for policies, so it
-- will not delete your teams, matches, or settings. It only adds the
-- group-stage tables/columns and replaces the tournament functions
-- with versions that know about group stage + knockout rounds
-- (Round of 16 / Quarter-Final / Semi-Final / Final).
--
-- If this is a brand new Supabase project, just run it top to bottom
-- and you're done — no other setup needed besides pasting your
-- project URL + anon key into js/config.js.
-- ==================================================================

create extension if not exists pgcrypto;

-- ------------------------------------------------------------------
-- 1. TABLES
-- ------------------------------------------------------------------

create table if not exists groups (
  id         uuid primary key default gen_random_uuid(),
  name       text not null,
  created_at timestamptz not null default now()
);

create table if not exists teams (
  id                    uuid primary key default gen_random_uuid(),
  team_name             text not null unique,
  owner_name            text,
  phone                 text not null,
  preferred_time        text,
  code                  text not null unique,
  status                text not null default 'active',
  group_id              uuid references groups(id) on delete set null,
  recovery_attempts     int not null default 0,
  recovery_locked_until timestamptz,
  created_at            timestamptz not null default now()
);

create table if not exists matches (
  id               uuid primary key default gen_random_uuid(),
  phase            text not null default 'knockout',
  group_id         uuid references groups(id) on delete cascade,
  round            int not null default 1,
  round_name       text,
  match_index      int not null default 0,
  team1_id         uuid references teams(id) on delete set null,
  team2_id         uuid references teams(id) on delete set null,
  is_bye           boolean not null default false,
  status           text not null default 'awaiting_schedule',
  scheduled_time   timestamptz,
  team1_score      int,
  team2_score      int,
  team1_penalties  int,
  team2_penalties  int,
  winner_id        uuid references teams(id) on delete set null,
  approved_by      uuid,
  approved_at      timestamptz,
  created_at       timestamptz not null default now()
);

create table if not exists tournament_settings (
  id                   int primary key default 1,
  tournament_name      text not null default 'eFootball Championship',
  status               text not null default 'registration',
  total_rounds         int,
  champion_id          uuid references teams(id) on delete set null,
  qualifiers_per_group int not null default 2,
  constraint tournament_settings_single_row check (id = 1)
);

-- upgrade path: add any columns that might be missing on an existing
-- project (harmless no-ops if they already exist)
alter table teams   add column if not exists group_id uuid references groups(id) on delete set null;
alter table teams   add column if not exists recovery_attempts int not null default 0;
alter table teams   add column if not exists recovery_locked_until timestamptz;
alter table matches add column if not exists phase text not null default 'knockout';
alter table matches add column if not exists group_id uuid references groups(id) on delete cascade;
alter table matches add column if not exists approved_by uuid;
alter table matches add column if not exists approved_at timestamptz;
alter table tournament_settings add column if not exists qualifiers_per_group int not null default 2;

-- normalize old status values from before the group stage existed
update tournament_settings set status = 'knockout' where status = 'ongoing';
update tournament_settings set status = 'completed' where status = 'complete';
update matches set phase = 'knockout' where phase is null;

-- ------------------------------------------------------------------
-- 2. CHECK CONSTRAINTS (drop + recreate so this file is re-runnable)
-- ------------------------------------------------------------------

alter table teams drop constraint if exists teams_status_check;
alter table teams add constraint teams_status_check
  check (status in ('active','eliminated','champion','withdrawn'));

alter table matches drop constraint if exists matches_phase_check;
alter table matches add constraint matches_phase_check
  check (phase in ('group','knockout'));

alter table matches drop constraint if exists matches_status_check;
alter table matches add constraint matches_status_check
  check (status in ('pending_teams','awaiting_schedule','scheduled','pending_approval','approved','disputed'));

alter table tournament_settings drop constraint if exists tournament_settings_status_check;
alter table tournament_settings add constraint tournament_settings_status_check
  check (status in ('registration','group_stage','knockout','completed'));

do $$
begin
  insert into tournament_settings (id, tournament_name, status)
  values (1, 'eFootball Championship', 'registration')
  on conflict (id) do nothing;
end $$;

-- Older versions of this schema (or a hand-built one) may have a
-- single UNIQUE(round, match_index) constraint. That doesn't work
-- anymore: group-stage fixtures and the knockout bracket both start
-- numbering match_index at 0 for round 1, and every group does the
-- same for its own fixtures — so "uniqueness" now needs to be scoped
-- per phase (and per group, for group matches) rather than global.
alter table matches drop constraint if exists matches_round_match_index_key;
drop index if exists matches_round_match_index_key;

-- helpful indexes
create index if not exists idx_matches_round on matches(phase, round, match_index);
create index if not exists idx_matches_group on matches(group_id);

-- correctly-scoped replacements for the old global constraint above:
-- one slot per (round, match_index) among knockout matches...
create unique index if not exists idx_matches_knockout_slot
  on matches(round, match_index) where phase = 'knockout';
-- ...and one slot per (group, round, match_index) among group matches
create unique index if not exists idx_matches_group_slot
  on matches(group_id, round, match_index) where phase = 'group';
create index if not exists idx_teams_group on teams(group_id);

-- ------------------------------------------------------------------
-- 3. PUBLIC VIEWS (safe columns only — no phone numbers or codes)
-- ------------------------------------------------------------------

create or replace view teams_public as
select id, team_name, status, created_at, group_id
from teams;

-- Sofascore-style group table: played / won / drawn / lost / goals /
-- goal difference / points / rank, computed live from approved
-- group-stage results. "position" is the row's rank inside its group.
create or replace view group_standings as
with gm as (
  select id, group_id, team1_id, team2_id, team1_score, team2_score
  from matches
  where phase = 'group' and status = 'approved' and not is_bye
),
per_team as (
  select
    g.id   as group_id,
    g.name as group_name,
    t.id   as team_id,
    t.team_name,
    gm.id  as match_id,
    case when gm.team1_id = t.id then gm.team1_score
         when gm.team2_id = t.id then gm.team2_score end as gf,
    case when gm.team1_id = t.id then gm.team2_score
         when gm.team2_id = t.id then gm.team1_score end as ga
  from teams t
  join groups g on g.id = t.group_id
  left join gm on g.id = gm.group_id and (gm.team1_id = t.id or gm.team2_id = t.id)
  where t.group_id is not null
),
agg as (
  select
    group_id, group_name, team_id, team_name,
    count(match_id)                       as played,
    count(*) filter (where gf > ga)       as won,
    count(*) filter (where gf = ga and match_id is not null) as drawn,
    count(*) filter (where gf < ga)       as lost,
    coalesce(sum(gf), 0)                  as goals_for,
    coalesce(sum(ga), 0)                  as goals_against
  from per_team
  group by group_id, group_name, team_id, team_name
)
select
  group_id, group_name, team_id, team_name,
  played, won, drawn, lost,
  goals_for, goals_against,
  (goals_for - goals_against) as goal_diff,
  (won * 3 + drawn)           as points,
  rank() over (
    partition by group_id
    order by (won * 3 + drawn) desc, (goals_for - goals_against) desc, goals_for desc, team_name asc
  ) as position
from agg;

grant select on teams_public     to anon, authenticated;
grant select on group_standings  to anon, authenticated;
grant select on groups           to anon, authenticated;
grant select on tournament_settings to anon, authenticated;
grant select on matches          to anon, authenticated;

-- belt-and-braces table grants for admins (RLS policies below still
-- decide row-by-row access — this just makes sure the base privilege
-- exists no matter how this project's defaults were configured)
grant select, insert, update, delete on teams, matches, groups, tournament_settings to authenticated;
grant usage on schema public to anon, authenticated;
grant execute on all functions in schema public to anon, authenticated;

-- ------------------------------------------------------------------
-- 4. HELPER FUNCTIONS
-- ------------------------------------------------------------------

create or replace function round_name_for(p_round int, p_total_rounds int)
returns text
language sql
immutable
as $$
  select case (p_total_rounds - p_round)
    when 0 then 'Final'
    when 1 then 'Semi-Final'
    when 2 then 'Quarter-Final'
    else 'Round of ' || power(2, (p_total_rounds - p_round) + 1)::int::text
  end;
$$;

create or replace function generate_team_code()
returns text
language plpgsql
as $$
declare
  chars text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; -- no 0/O or 1/I, avoids confusion
  result text;
  i int;
  taken boolean;
begin
  loop
    result := '';
    for i in 1..6 loop
      result := result || substr(chars, floor(random() * length(chars))::int + 1, 1);
    end loop;
    select exists(select 1 from teams where code = result) into taken;
    exit when not taken;
  end loop;
  return result;
end;
$$;

-- ------------------------------------------------------------------
-- 5. PUBLIC-FACING RPCs (SECURITY DEFINER — callable by anon)
-- ------------------------------------------------------------------

create or replace function register_team(
  p_team_name text, p_owner_name text, p_phone text, p_preferred_time text
) returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_status text;
  v_code text;
begin
  select status into v_status from tournament_settings where id = 1;
  if v_status is distinct from 'registration' then
    raise exception 'Registration is closed — the tournament has already started.';
  end if;
  if p_team_name is null or length(trim(p_team_name)) < 2 then
    raise exception 'Enter a valid team name.';
  end if;
  if p_phone is null or length(trim(p_phone)) < 6 then
    raise exception 'Enter a valid phone number.';
  end if;
  if exists (select 1 from teams where lower(team_name) = lower(trim(p_team_name))) then
    raise exception 'That team name is already taken — pick another.';
  end if;

  v_code := generate_team_code();

  insert into teams (team_name, owner_name, phone, preferred_time, code, status)
  values (
    trim(p_team_name),
    nullif(trim(coalesce(p_owner_name, '')), ''),
    trim(p_phone),
    nullif(trim(coalesce(p_preferred_time, '')), ''),
    v_code,
    'active'
  );

  return v_code;
end;
$$;

create or replace function recover_team_code(p_team_name text, p_phone text)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_team teams%rowtype;
begin
  select * into v_team from teams where lower(team_name) = lower(trim(p_team_name));
  if not found then
    raise exception 'No team found with that name.';
  end if;
  if v_team.recovery_locked_until is not null and v_team.recovery_locked_until > now() then
    raise exception 'Too many attempts — recovery is locked until %. Ask the admin to unlock it.',
      to_char(v_team.recovery_locked_until, 'HH12:MI AM');
  end if;
  if v_team.phone <> trim(p_phone) then
    update teams set
      recovery_attempts = coalesce(recovery_attempts, 0) + 1,
      recovery_locked_until = case
        when coalesce(recovery_attempts, 0) + 1 >= 5 then now() + interval '30 minutes'
        else recovery_locked_until
      end
    where id = v_team.id;
    raise exception 'Team name and phone number do not match our records.';
  end if;
  update teams set recovery_attempts = 0, recovery_locked_until = null where id = v_team.id;
  return v_team.code;
end;
$$;

create or replace function submit_match_result(
  p_match_id uuid, p_code text, p_score1 int, p_score2 int, p_pen1 int default null, p_pen2 int default null
) returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_match matches%rowtype;
  v_team  teams%rowtype;
begin
  select * into v_match from matches where id = p_match_id;
  if not found then raise exception 'Fixture not found.'; end if;
  if v_match.is_bye then raise exception 'Byes are confirmed automatically — no result needed.'; end if;
  if v_match.team1_id is null or v_match.team2_id is null then
    raise exception 'Both teams are not set for this fixture yet.';
  end if;
  if v_match.status = 'approved' then
    raise exception 'This result has already been approved.';
  end if;

  select * into v_team from teams
    where code = upper(trim(p_code)) and (id = v_match.team1_id or id = v_match.team2_id);
  if not found then
    raise exception 'That code does not match either team in this fixture.';
  end if;

  if p_score1 is null or p_score2 is null or p_score1 < 0 or p_score2 < 0 then
    raise exception 'Enter valid scores for both teams.';
  end if;

  if v_match.phase = 'knockout' and p_score1 = p_score2 then
    if p_pen1 is null or p_pen2 is null or p_pen1 = p_pen2 then
      raise exception 'Level scores in a knockout match need a penalty shootout result.';
    end if;
  end if;

  update matches set
    team1_score     = p_score1,
    team2_score     = p_score2,
    team1_penalties = case when v_match.phase = 'knockout' then p_pen1 else null end,
    team2_penalties = case when v_match.phase = 'knockout' then p_pen2 else null end,
    status          = 'pending_approval'
  where id = p_match_id;
end;
$$;

-- ------------------------------------------------------------------
-- 6. ADMIN RPCs (SECURITY DEFINER, but require a logged-in session)
-- ------------------------------------------------------------------

-- Approves a match. For knockout matches this also determines the
-- winner, eliminates the loser, advances the winner into the next
-- round (Round of 16 → Quarter-Final → Semi-Final → Final), creates
-- that next-round fixture if it doesn't exist yet, and — on the
-- Final — crowns the champion. For group matches it just records the
-- score; draws are allowed and nobody is eliminated (standings are
-- computed live by the group_standings view instead).
create or replace function approve_match(
  p_match_id uuid, p_score1 int default null, p_score2 int default null, p_pen1 int default null, p_pen2 int default null
) returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_match    matches%rowtype;
  v_settings tournament_settings%rowtype;
  v_score1   int;
  v_score2   int;
  v_winner   uuid;
  v_loser    uuid;
  v_next_round int;
  v_next_index int;
  v_slot       text;
  v_next       matches%rowtype;
  v_round_name text;
begin
  if auth.uid() is null then
    raise exception 'Not authorized.';
  end if;

  select * into v_match from matches where id = p_match_id;
  if not found then raise exception 'Fixture not found.'; end if;

  select * into v_settings from tournament_settings where id = 1;

  v_score1 := coalesce(p_score1, v_match.team1_score);
  v_score2 := coalesce(p_score2, v_match.team2_score);

  if v_match.is_bye then
    v_winner := v_match.team1_id;
    update matches set status = 'approved', winner_id = v_winner where id = v_match.id;

  elsif v_match.phase = 'group' then
    if v_score1 is null or v_score2 is null then
      raise exception 'Enter both scores before approving.';
    end if;
    v_winner := case
      when v_score1 > v_score2 then v_match.team1_id
      when v_score2 > v_score1 then v_match.team2_id
      else null
    end;
    update matches set
      team1_score = v_score1, team2_score = v_score2,
      status = 'approved', winner_id = v_winner
    where id = v_match.id;
    return; -- group matches don't advance anyone or eliminate anyone

  else
    -- knockout match with two real teams
    if v_score1 is null or v_score2 is null then
      raise exception 'Enter both scores before approving.';
    end if;
    if v_score1 = v_score2 then
      if p_pen1 is null or p_pen2 is null or p_pen1 = p_pen2 then
        raise exception 'A level knockout match needs a decisive penalty result.';
      end if;
      v_winner := case when p_pen1 > p_pen2 then v_match.team1_id else v_match.team2_id end;
    else
      v_winner := case when v_score1 > v_score2 then v_match.team1_id else v_match.team2_id end;
    end if;
    v_loser := case when v_winner = v_match.team1_id then v_match.team2_id else v_match.team1_id end;

    update matches set
      team1_score = v_score1, team2_score = v_score2,
      team1_penalties = p_pen1, team2_penalties = p_pen2,
      status = 'approved', winner_id = v_winner
    where id = v_match.id;

    if v_loser is not null then
      update teams set status = 'eliminated' where id = v_loser and status <> 'eliminated';
    end if;
  end if;

  -- ---- knockout advancement (also runs for confirmed byes) ----
  if v_settings.total_rounds is null then
    return;
  end if;

  if v_match.round >= v_settings.total_rounds then
    -- that was the Final
    update tournament_settings set status = 'completed', champion_id = v_winner where id = 1;
    update teams set status = 'champion' where id = v_winner;
    return;
  end if;

  v_next_round := v_match.round + 1;
  v_next_index := v_match.match_index / 2;               -- integer division
  v_slot       := case when v_match.match_index % 2 = 0 then 'team1' else 'team2' end;
  v_round_name := round_name_for(v_next_round, v_settings.total_rounds);

  select * into v_next from matches
    where phase = 'knockout' and round = v_next_round and match_index = v_next_index;

  if not found then
    if v_slot = 'team1' then
      insert into matches (phase, round, round_name, match_index, team1_id, status)
        values ('knockout', v_next_round, v_round_name, v_next_index, v_winner, 'pending_teams');
    else
      insert into matches (phase, round, round_name, match_index, team2_id, status)
        values ('knockout', v_next_round, v_round_name, v_next_index, v_winner, 'pending_teams');
    end if;
  else
    if v_slot = 'team1' then
      update matches set
        team1_id = v_winner,
        round_name = v_round_name,
        status = case when team2_id is not null then 'awaiting_schedule' else 'pending_teams' end
      where id = v_next.id;
    else
      update matches set
        team2_id = v_winner,
        round_name = v_round_name,
        status = case when team1_id is not null then 'awaiting_schedule' else 'pending_teams' end
      where id = v_next.id;
    end if;
  end if;
end;
$$;

-- Builds a single round-robin fixture list inside every group, for
-- every team currently assigned to a group. Safe to re-run: it only
-- touches fixtures that haven't been approved yet, and skips any
-- pairing that already has an approved result.
create or replace function generate_group_fixtures()
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  g record;
  team_ids uuid[];
  n int;
  i int;
  j int;
  idx int;
begin
  if auth.uid() is null then raise exception 'Not authorized.'; end if;

  delete from matches where phase = 'group' and status <> 'approved';

  for g in select id from groups loop
    select array_agg(id order by team_name) into team_ids
      from teams where group_id = g.id and status = 'active';
    n := coalesce(array_length(team_ids, 1), 0);
    if n >= 2 then
      idx := coalesce((select max(match_index) + 1 from matches where phase = 'group' and group_id = g.id), 0);
      for i in 1..n-1 loop
        for j in i+1..n loop
          if not exists (
            select 1 from matches
            where phase = 'group' and group_id = g.id and status = 'approved'
              and ((team1_id = team_ids[i] and team2_id = team_ids[j])
                or (team1_id = team_ids[j] and team2_id = team_ids[i]))
          ) then
            insert into matches (phase, group_id, round, match_index, team1_id, team2_id, status)
              values ('group', g.id, 1, idx, team_ids[i], team_ids[j], 'awaiting_schedule');
            idx := idx + 1;
          end if;
        end loop;
      end loop;
    end if;
  end loop;
end;
$$;

-- Moves the tournament from "registration" into "group_stage":
-- requires at least one group and every active team assigned to one,
-- then builds the round-robin fixtures.
create or replace function start_group_stage()
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_settings tournament_settings%rowtype;
  v_unassigned int;
  v_groups int;
begin
  if auth.uid() is null then raise exception 'Not authorized.'; end if;

  select * into v_settings from tournament_settings where id = 1;
  if v_settings.status <> 'registration' then
    raise exception 'The group stage can only be started from registration.';
  end if;

  select count(*) into v_groups from groups;
  if v_groups < 1 then raise exception 'Create at least one group first.'; end if;

  select count(*) into v_unassigned from teams where status = 'active' and group_id is null;
  if v_unassigned > 0 then
    raise exception '% active team(s) are not assigned to a group yet.', v_unassigned;
  end if;

  perform generate_group_fixtures();
  update tournament_settings set status = 'group_stage' where id = 1;
end;
$$;

-- Closes the group stage: every group match must be approved. Takes
-- the top N teams from every group (N = qualifiers_per_group),
-- eliminates the rest, seeds the knockout bracket (1st-place teams
-- vs the lowest seeds first, in the usual "protect the group
-- winners" pattern), and opens Round 1 of the knockout stage with
-- the right name (Round of 16 / Quarter-Final / Semi-Final / Final).
create or replace function finalize_group_stage()
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_settings tournament_settings%rowtype;
  v_qualifiers_per_group int;
  v_group_count int;
  v_total_qualifiers int;
  v_total_rounds int;
  v_unplayed int;
  seed_order uuid[];
  n int;
  i int;
  idx int := 0;
  v_round_name text;
begin
  if auth.uid() is null then raise exception 'Not authorized.'; end if;

  select * into v_settings from tournament_settings where id = 1;
  if v_settings.status <> 'group_stage' then
    raise exception 'The tournament is not currently in the group stage.';
  end if;

  select count(*) into v_unplayed from matches where phase = 'group' and status <> 'approved';
  if v_unplayed > 0 then
    raise exception 'All group matches must be approved before finalizing (% left).', v_unplayed;
  end if;

  v_qualifiers_per_group := coalesce(v_settings.qualifiers_per_group, 2);
  select count(*) into v_group_count from groups;
  v_total_qualifiers := v_qualifiers_per_group * v_group_count;

  if v_total_qualifiers < 2 or (v_total_qualifiers & (v_total_qualifiers - 1)) <> 0 then
    raise exception
      'Qualifiers (% groups × % per group = %) must add up to a power of two (2, 4, 8, 16…) to build a clean knockout bracket. Adjust the qualifier count or number of groups.',
      v_group_count, v_qualifiers_per_group, v_total_qualifiers;
  end if;

  -- all group winners first, then all runners-up, then all 3rd places…
  seed_order := array(
    select team_id from group_standings
    where position <= v_qualifiers_per_group
    order by position asc, group_name asc
  );

  n := coalesce(array_length(seed_order, 1), 0);
  if n <> v_total_qualifiers then
    raise exception
      'Expected % qualifiers but found %. Make sure every group has at least % teams.',
      v_total_qualifiers, n, v_qualifiers_per_group;
  end if;
  v_total_rounds := round(log(2, n))::int;

  update teams set status = 'eliminated'
  where group_id is not null and status = 'active' and id <> all(seed_order);

  -- standard seeding: best seed vs worst seed, 2nd best vs 2nd worst…
  for i in 1..(n/2) loop
    v_round_name := round_name_for(1, v_total_rounds);
    insert into matches (phase, round, round_name, match_index, team1_id, team2_id, status)
      values ('knockout', 1, v_round_name, idx, seed_order[i], seed_order[n - i + 1], 'awaiting_schedule');
    idx := idx + 1;
  end loop;

  update tournament_settings set status = 'knockout', total_rounds = v_total_rounds where id = 1;
end;
$$;

-- ------------------------------------------------------------------
-- 7. ROW LEVEL SECURITY
-- ------------------------------------------------------------------

alter table teams               enable row level security;
alter table matches             enable row level security;
alter table groups              enable row level security;
alter table tournament_settings enable row level security;

-- teams: no direct anon access (use teams_public / the RPCs above);
-- signed-in admins can do anything.
drop policy if exists teams_admin_all on teams;
create policy teams_admin_all on teams
  for all to authenticated using (true) with check (true);

-- matches: everyone can read (the bracket/results are public); only
-- signed-in admins can write directly (public writes go through the
-- submit_match_result / approve_match RPCs, which run as the table
-- owner and bypass this policy on purpose).
drop policy if exists matches_public_read on matches;
create policy matches_public_read on matches
  for select to anon, authenticated using (true);

drop policy if exists matches_admin_write on matches;
create policy matches_admin_write on matches
  for all to authenticated using (true) with check (true);

-- groups: public read (so group names show on the standings tables),
-- admin write.
drop policy if exists groups_public_read on groups;
create policy groups_public_read on groups
  for select to anon, authenticated using (true);

drop policy if exists groups_admin_write on groups;
create policy groups_admin_write on groups
  for all to authenticated using (true) with check (true);

-- tournament_settings: public read, admin write.
drop policy if exists settings_public_read on tournament_settings;
create policy settings_public_read on tournament_settings
  for select to anon, authenticated using (true);

drop policy if exists settings_admin_write on tournament_settings;
create policy settings_admin_write on tournament_settings
  for all to authenticated using (true) with check (true);

-- ------------------------------------------------------------------
-- Done. Next: Authentication → Users → add yourself as an admin
-- (email + password), and open admin.html to sign in.
-- ==================================================================
