# eFootball Championship

A live tournament bracket site: group stage → knockouts, with team
registration, self-service result submission, and an admin panel to
run the whole thing from a phone.

## What's new in this update

1. **Group stage before the knockouts.** Admin creates groups, assigns
   teams, starts the group stage (round-robin fixtures are generated
   automatically), and finalizes it once every group match is
   approved — which seeds the knockout bracket with the qualifiers.
2. **Round names throughout the knockouts.** Every knockout round is
   labelled automatically — *Round of 16 → Quarter‑Final → Semi‑Final
   → Final* — both on the bracket itself and as a "Now playing…" pill
   above it.
3. **A proper bracket visual.** Matches are connected with arrows
   showing which winner goes where, and there's a trophy at the end
   of the Final — filled in with the champion's name once it's
   decided.
4. **A real dark mode.** Toggle it from the little moon/sun button in
   the header (public site and admin panel both). It's a from-scratch
   dark palette, not an inverted light theme, and it fixes the white
   flashes you were seeing — more on that below.

## 1. Set up the database

Open your Supabase project → **SQL Editor** → New query, paste in the
entire contents of **`supabase/schema.sql`**, and run it.

This is safe to run on your existing project — it only creates
tables/columns that don't already exist and replaces the app's
functions, so none of your current teams or results are touched. If
you're starting a brand new Supabase project, it's also everything
you need — just run it top to bottom.

After running it (first time only): go to **Authentication → Users**
and add yourself as an admin (email + password) — that's what you'll
sign in with on `admin.html`.

Then make sure **`js/config.js`** has your project's URL and anon key
(yours already does, since this is your existing project).

## 2. Running a tournament (with groups)

As admin:

1. **Teams** tab — teams register themselves from the public site
   during registration; you can see everyone's code here.
2. **Groups** tab — add your groups (e.g. "Group A", "Group B"),
   assign every active team into one, then **Start group stage**.
   This locks assignment and generates every group's round-robin
   fixtures.
3. Players submit results from the public **Submit** tab (draws are
   allowed in the group stage — no penalties needed); you approve
   them from **Approvals**. The **Groups** tab shows live standings
   as you go.
4. Once every group match is approved, hit **Finalize & start
   knockouts** in the Groups tab. This eliminates everyone who didn't
   qualify and opens Round 1 of the knockouts, named correctly for
   however many teams qualified (Round of 16, Quarter-Final, etc.)
5. From here it's the same flow as before: schedule fixtures, players
   submit scores (now penalties *are* required if a knockout match
   ends level), you approve, and the bracket advances itself —
   automatically creating the next round's fixture and, on the Final,
   crowning the champion.

**Prefer to skip groups entirely?** The **Bracket** tab still lets you
build Round 1 directly, exactly like before — just don't create any
groups and that tab stays usable. (If groups exist, the direct-bracket
form hides itself so the two flows can't collide.)

**Qualifiers per group** (Settings tab) controls how many teams
advance from each group. The number of groups × qualifiers per group
must add up to a power of two (2, 4, 8, 16…) so the bracket comes out
clean — the app will tell you if it doesn't when you try to finalize.

## 3. About the dark mode fix

The site never actually had a working dark mode before — the toggle
button in the admin panel existed in the markup but had no code
behind it, and neither page declared any dark colors at all. What you
were seeing was your **browser's own "force dark" mode** stepping in
uninvited: because the page never says what its color scheme is,
Android Chrome (and similar) tries to auto-darken it, and does so
unevenly — form fields, scrollbars, and date pickers often stay their
original white while everything else gets inverted. That's the
"disturbing white" you ran into.

The fix is two-fold, both in `css/style.css`:

- A real dark palette (`[data-theme="dark"]`), built the same
  soft-shadow "neumorphic" way as the light theme, just on a deep
  slate-navy base instead of pure black.
- Declaring `color-scheme: light` / `color-scheme: dark` explicitly.
  That one line is what tells the browser "I've got this — don't
  auto-darken me," which is what actually stops the white flashes,
  independent of whether someone uses the toggle or not.

The toggle itself (top-right on both pages) remembers your choice
per-device via `localStorage`, and falls back to your system's light/
dark setting the first time you visit.

## Files

```
index.html            Public site (Groups / Bracket / Teams / Register / Submit)
admin.html             Admin panel (Teams / Groups / Bracket / Approvals / Fixtures / Settings)
css/style.css          All styling, incl. dark mode + bracket visuals
js/config.js            Your Supabase URL + anon key
js/theme.js             Dark mode toggle (shared by both pages)
js/main.js              Public site logic
js/admin.js              Admin panel logic
supabase/schema.sql      Full database setup — run this in Supabase's SQL editor
manifest.json / manifest-admin.json   PWA manifests ("Add to Home Screen")
sw.js                    Offline app-shell caching
icons/                   App icons (were missing before — this was silently
                          breaking "Add to Home Screen" since the old
                          manifest/service worker pointed at files that
                          didn't exist in the project)
```
